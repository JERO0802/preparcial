package org.demo.Models;

public enum TipoInmueble {
    CASA,
    APARTAMENTO,
    FINCA,
    LOCAL;
}
