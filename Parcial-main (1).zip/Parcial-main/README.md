Cree una aplicación Java y JavaFX que capture datos sobre inmuebles (tipo (casa, apartamento, finca, local), ciudad, número de habitaciones, numero de pisos, precio), los guarde en un ArrayList y muestre el listado de los datos capturados.

Utilice un dashboard principal dentro del cual se muestren los componentes formulario y listado con la opciṕn de eliminar el inmueble seleccionado.

Juan Miguel Henao Gaviria

Jerónimo Delgado Estrada
